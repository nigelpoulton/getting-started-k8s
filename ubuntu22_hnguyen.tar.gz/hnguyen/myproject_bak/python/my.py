#!/usr/bin/env python3
import datetime
date =  datetime.datetime.now()
print(date)

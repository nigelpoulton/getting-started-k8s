# comptia-automation
Used on my Comptia Linux+ course Automation Section

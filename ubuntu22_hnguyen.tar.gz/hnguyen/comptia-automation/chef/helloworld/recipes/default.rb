file "#{ENV['HOME']}/hello.txt" do
 content "This is line 1\nand this is line 2\n"
 mode '0700'
end
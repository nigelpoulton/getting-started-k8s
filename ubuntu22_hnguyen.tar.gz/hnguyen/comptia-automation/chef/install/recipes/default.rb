package %w(vim zsh tree) do
  action :install
end
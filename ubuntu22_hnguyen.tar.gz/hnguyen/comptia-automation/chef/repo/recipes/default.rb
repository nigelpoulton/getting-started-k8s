git "#{ENV['HOME']}/comptia-automation/" do
  repository 'https://github.com/theurbanpenguin/comptia-automation.git'
  revision 'main'
  action :sync
end
#!/usr/bin/env python3
import datetime
print (datetime.datetime.now())